"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/09-quiz/09-01-react-daum-postcode";
exports.ids = ["pages/09-quiz/09-01-react-daum-postcode"];
exports.modules = {

/***/ "./pages/09-quiz/09-01-react-daum-postcode/index.tsx":
/*!***********************************************************!*\
  !*** ./pages/09-quiz/09-01-react-daum-postcode/index.tsx ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ReactDaumPostcodePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-daum-postcode */ \"react-daum-postcode\");\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_daum_postcode__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction ReactDaumPostcodePage() {\n    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);\n    const handleComplete = (data)=>{\n        setIsOpen(true);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: isOpen && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_daum_postcode__WEBPACK_IMPORTED_MODULE_1___default()), {\n            onComplete: handleComplete\n        }, void 0, false, {\n            fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-01-react-daum-postcode/index.tsx\",\n            lineNumber: 18,\n            columnNumber: 13\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOS1xdWl6LzA5LTAxLXJlYWN0LWRhdW0tcG9zdGNvZGUvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQThDO0FBQ2Q7QUFJakIsUUFBUSxDQUFDRSxxQkFBcUIsR0FBRSxDQUFDO0lBRTVDLEtBQUssTUFBRUMsTUFBTSxNQUFFQyxTQUFTLE1BQUlILCtDQUFRLENBQUMsSUFBSTtJQUV6QyxLQUFLLENBQUNJLGNBQWMsSUFBSUMsSUFBUyxHQUFLLENBQUM7UUFDbkNGLFNBQVMsQ0FBQyxJQUFJO0lBQ2xCLENBQUM7SUFHRCxNQUFNO2tCQUVERCxNQUFNLGdGQUNGSCw0REFBWTtZQUFDTyxVQUFVLEVBQUVGLGNBQWM7Ozs7Ozs7QUFJcEQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9wYWdlcy8wOS1xdWl6LzA5LTAxLXJlYWN0LWRhdW0tcG9zdGNvZGUvaW5kZXgudHN4P2U4YWEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IERhdW1Qb3N0Y29kZSBmcm9tICdyZWFjdC1kYXVtLXBvc3Rjb2RlJztcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVhY3REYXVtUG9zdGNvZGVQYWdlKCl7XG5cbiAgICBjb25zdCBbaXNPcGVuLCBzZXRJc09wZW5dID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgXG4gICAgY29uc3QgaGFuZGxlQ29tcGxldGUgPSAoZGF0YTogYW55KSA9PiB7XG4gICAgICAgIHNldElzT3Blbih0cnVlKVxuICAgIH1cblxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAge2lzT3BlbiAmJlxuICAgICAgICAgICAgPERhdW1Qb3N0Y29kZSBvbkNvbXBsZXRlPXtoYW5kbGVDb21wbGV0ZX0vPlxuICAgICAgICB9XG4gICAgICAgIDwvPlxuICAgIClcbn0iXSwibmFtZXMiOlsiRGF1bVBvc3Rjb2RlIiwidXNlU3RhdGUiLCJSZWFjdERhdW1Qb3N0Y29kZVBhZ2UiLCJpc09wZW4iLCJzZXRJc09wZW4iLCJoYW5kbGVDb21wbGV0ZSIsImRhdGEiLCJvbkNvbXBsZXRlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/09-quiz/09-01-react-daum-postcode/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-daum-postcode":
/*!**************************************!*\
  !*** external "react-daum-postcode" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("react-daum-postcode");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/09-quiz/09-01-react-daum-postcode/index.tsx"));
module.exports = __webpack_exports__;

})();