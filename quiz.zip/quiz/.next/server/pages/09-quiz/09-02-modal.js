"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/09-quiz/09-02-modal";
exports.ids = ["pages/09-quiz/09-02-modal"];
exports.modules = {

/***/ "./pages/09-quiz/09-02-modal/index.tsx":
/*!*********************************************!*\
  !*** ./pages/09-quiz/09-02-modal/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ModalPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction ModalPage() {\n    const { 0: isModalVisible , 1: setIsModalVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const showModal = ()=>{\n        setIsModalVisible(true);\n    };\n    const handleOk = ()=>{\n        setIsModalVisible(false);\n    };\n    const handleCancel = ()=>{\n        setIsModalVisible(false);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_1__.Button, {\n                onClick: showModal,\n                children: \"모달열기\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-02-modal/index.tsx\",\n                lineNumber: 22,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_1__.Modal, {\n                visible: isModalVisible,\n                onOk: handleOk,\n                onCancel: handleCancel\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-02-modal/index.tsx\",\n                lineNumber: 25,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOS1xdWl6LzA5LTAyLW1vZGFsL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFvQztBQUNKO0FBRWpCLFFBQVEsQ0FBQ0csU0FBUyxHQUFFLENBQUM7SUFDaEMsS0FBSyxNQUFFQyxjQUFjLE1BQUVDLGlCQUFpQixNQUFJSCwrQ0FBUSxDQUFDLEtBQUs7SUFFMUQsS0FBSyxDQUFDSSxTQUFTLE9BQVMsQ0FBQztRQUN2QkQsaUJBQWlCLENBQUMsSUFBSTtJQUN4QixDQUFDO0lBRUQsS0FBSyxDQUFDRSxRQUFRLE9BQVMsQ0FBQztRQUN0QkYsaUJBQWlCLENBQUMsS0FBSztJQUN6QixDQUFDO0lBRUQsS0FBSyxDQUFDRyxZQUFZLE9BQVMsQ0FBQztRQUMxQkgsaUJBQWlCLENBQUMsS0FBSztJQUN6QixDQUFDO0lBR0QsTUFBTTs7d0ZBRURKLHdDQUFNO2dCQUFDUSxPQUFPLEVBQUVILFNBQVM7MEJBQUUsQ0FFNUI7Ozs7Ozt3RkFDQ04sdUNBQUs7Z0JBQUNVLE9BQU8sRUFBRU4sY0FBYztnQkFBRU8sSUFBSSxFQUFFSixRQUFRO2dCQUFFSyxRQUFRLEVBQUVKLFlBQVk7Ozs7Ozs7O0FBSzVFLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vcGFnZXMvMDktcXVpei8wOS0wMi1tb2RhbC9pbmRleC50c3g/YjYzNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb2RhbCwgQnV0dG9uIH0gZnJvbSAnYW50ZCc7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9kYWxQYWdlKCl7XG4gICAgY29uc3QgW2lzTW9kYWxWaXNpYmxlLCBzZXRJc01vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIFxuICAgIGNvbnN0IHNob3dNb2RhbCA9ICgpID0+IHtcbiAgICAgIHNldElzTW9kYWxWaXNpYmxlKHRydWUpO1xuICAgIH07XG4gIFxuICAgIGNvbnN0IGhhbmRsZU9rID0gKCkgPT4ge1xuICAgICAgc2V0SXNNb2RhbFZpc2libGUoZmFsc2UpO1xuICAgIH07XG4gIFxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICAgIHNldElzTW9kYWxWaXNpYmxlKGZhbHNlKTtcbiAgICB9O1xuICBcblxuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3Nob3dNb2RhbH0+XG4gICAgICAgICAg66qo64us7Je06riwXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8TW9kYWwgdmlzaWJsZT17aXNNb2RhbFZpc2libGV9IG9uT2s9e2hhbmRsZU9rfSBvbkNhbmNlbD17aGFuZGxlQ2FuY2VsfT5cblxuICAgICAgICA8L01vZGFsPlxuICAgICAgPC8+XG4gICAgKTtcbiAgfTsiXSwibmFtZXMiOlsiTW9kYWwiLCJCdXR0b24iLCJ1c2VTdGF0ZSIsIk1vZGFsUGFnZSIsImlzTW9kYWxWaXNpYmxlIiwic2V0SXNNb2RhbFZpc2libGUiLCJzaG93TW9kYWwiLCJoYW5kbGVPayIsImhhbmRsZUNhbmNlbCIsIm9uQ2xpY2siLCJ2aXNpYmxlIiwib25PayIsIm9uQ2FuY2VsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/09-quiz/09-02-modal/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/09-quiz/09-02-modal/index.tsx"));
module.exports = __webpack_exports__;

})();