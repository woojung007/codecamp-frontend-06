"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/09-quiz/09-03-modal-postcode";
exports.ids = ["pages/09-quiz/09-03-modal-postcode"];
exports.modules = {

/***/ "./pages/09-quiz/09-03-modal-postcode/index.tsx":
/*!******************************************************!*\
  !*** ./pages/09-quiz/09-03-modal-postcode/index.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ModalPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-daum-postcode */ \"react-daum-postcode\");\n/* harmony import */ var react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_daum_postcode__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction ModalPage() {\n    const { 0: isModalVisible , 1: setIsModalVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const showModal = ()=>{\n        setIsModalVisible(true);\n    };\n    const handleOk = ()=>{\n        setIsModalVisible(false);\n    };\n    const handleCancel = ()=>{\n        setIsModalVisible(false);\n    };\n    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const handleComplete = (data)=>{\n        setIsOpen(true);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_1__.Button, {\n                onClick: showModal,\n                children: \"모달열기\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-03-modal-postcode/index.tsx\",\n                lineNumber: 31,\n                columnNumber: 9\n            }, this),\n            isOpen && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_daum_postcode__WEBPACK_IMPORTED_MODULE_3___default()), {\n                onComplete: handleComplete\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-03-modal-postcode/index.tsx\",\n                lineNumber: 35,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOS1xdWl6LzA5LTAzLW1vZGFsLXBvc3Rjb2RlL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQW9DO0FBQ0o7QUFDYztBQUcvQixRQUFRLENBQUNHLFNBQVMsR0FBRSxDQUFDO0lBQ2hDLEtBQUssTUFBRUMsY0FBYyxNQUFFQyxpQkFBaUIsTUFBSUosK0NBQVEsQ0FBQyxLQUFLO0lBRTFELEtBQUssQ0FBQ0ssU0FBUyxPQUFTLENBQUM7UUFDdkJELGlCQUFpQixDQUFDLElBQUk7SUFDeEIsQ0FBQztJQUVELEtBQUssQ0FBQ0UsUUFBUSxPQUFTLENBQUM7UUFDdEJGLGlCQUFpQixDQUFDLEtBQUs7SUFDekIsQ0FBQztJQUVELEtBQUssQ0FBQ0csWUFBWSxPQUFTLENBQUM7UUFDMUJILGlCQUFpQixDQUFDLEtBQUs7SUFDekIsQ0FBQztJQUdELEtBQUssTUFBRUksTUFBTSxNQUFFQyxTQUFTLE1BQUlULCtDQUFRLENBQUMsS0FBSztJQUUxQyxLQUFLLENBQUNVLGNBQWMsSUFBSUMsSUFBUyxHQUFLLENBQUM7UUFDbkNGLFNBQVMsQ0FBQyxJQUFJO0lBQ2xCLENBQUM7SUFHRCxNQUFNOzt3RkFFRFYsd0NBQU07Z0JBQUNhLE9BQU8sRUFBRVAsU0FBUzswQkFBRSxDQUU1Qjs7Ozs7O1lBQ0NHLE1BQU0sZ0ZBQ0ZQLDREQUFZO2dCQUFDWSxVQUFVLEVBQUVILGNBQWM7Ozs7Ozs7O0FBSWxELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vcGFnZXMvMDktcXVpei8wOS0wMy1tb2RhbC1wb3N0Y29kZS9pbmRleC50c3g/YzI3MiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb2RhbCwgQnV0dG9uIH0gZnJvbSAnYW50ZCc7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBEYXVtUG9zdGNvZGUgZnJvbSAncmVhY3QtZGF1bS1wb3N0Y29kZSc7XG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9kYWxQYWdlKCl7XG4gICAgY29uc3QgW2lzTW9kYWxWaXNpYmxlLCBzZXRJc01vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIFxuICAgIGNvbnN0IHNob3dNb2RhbCA9ICgpID0+IHtcbiAgICAgIHNldElzTW9kYWxWaXNpYmxlKHRydWUpO1xuICAgIH07XG4gIFxuICAgIGNvbnN0IGhhbmRsZU9rID0gKCkgPT4ge1xuICAgICAgc2V0SXNNb2RhbFZpc2libGUoZmFsc2UpO1xuICAgIH07XG4gIFxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICAgIHNldElzTW9kYWxWaXNpYmxlKGZhbHNlKTtcbiAgICB9O1xuICBcblxuICAgIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgXG4gICAgY29uc3QgaGFuZGxlQ29tcGxldGUgPSAoZGF0YTogYW55KSA9PiB7XG4gICAgICAgIHNldElzT3Blbih0cnVlKVxuICAgIH1cblxuXG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxCdXR0b24gb25DbGljaz17c2hvd01vZGFsfT5cbiAgICAgICAgICDrqqjri6zsl7TquLBcbiAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIHtpc09wZW4gJiZcbiAgICAgICAgICAgIDxEYXVtUG9zdGNvZGUgb25Db21wbGV0ZT17aGFuZGxlQ29tcGxldGV9Lz5cbiAgICAgICAgfVxuICAgICAgPC8+XG4gICAgKTtcbiAgfTsiXSwibmFtZXMiOlsiQnV0dG9uIiwidXNlU3RhdGUiLCJEYXVtUG9zdGNvZGUiLCJNb2RhbFBhZ2UiLCJpc01vZGFsVmlzaWJsZSIsInNldElzTW9kYWxWaXNpYmxlIiwic2hvd01vZGFsIiwiaGFuZGxlT2siLCJoYW5kbGVDYW5jZWwiLCJpc09wZW4iLCJzZXRJc09wZW4iLCJoYW5kbGVDb21wbGV0ZSIsImRhdGEiLCJvbkNsaWNrIiwib25Db21wbGV0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/09-quiz/09-03-modal-postcode/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-daum-postcode":
/*!**************************************!*\
  !*** external "react-daum-postcode" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("react-daum-postcode");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/09-quiz/09-03-modal-postcode/index.tsx"));
module.exports = __webpack_exports__;

})();