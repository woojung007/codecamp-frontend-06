"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/09-quiz/09-04-State-prev";
exports.ids = ["pages/09-quiz/09-04-State-prev"];
exports.modules = {

/***/ "./pages/09-quiz/09-04-State-prev/index.tsx":
/*!**************************************************!*\
  !*** ./pages/09-quiz/09-04-State-prev/index.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ PrevstatePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction PrevstatePage() {\n    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    function sumAll() {\n        setState((prev)=>prev + 1\n        );\n        setState((prev)=>prev + 2\n        );\n        setState((prev)=>prev + 3\n        );\n        setState((prev)=>prev + 4\n        );\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"결과는: \",\n                    state\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-04-State-prev/index.tsx\",\n                lineNumber: 17,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: sumAll,\n                children: \"실행!\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/09-quiz/09-04-State-prev/index.tsx\",\n                lineNumber: 18,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOS1xdWl6LzA5LTA0LVN0YXRlLXByZXYvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFnQztBQUNqQixRQUFRLENBQUNDLGFBQWEsR0FBRSxDQUFDO0lBRXBDLEtBQUssTUFBRUMsS0FBSyxNQUFFQyxRQUFRLE1BQUlILCtDQUFRLENBQUMsQ0FBQzthQUUzQkksTUFBTSxHQUFFLENBQUM7UUFDZEQsUUFBUSxFQUFFRSxJQUFJLEdBQU1BLElBQUksR0FBRyxDQUFDOztRQUM1QkYsUUFBUSxFQUFFRSxJQUFJLEdBQU1BLElBQUksR0FBRyxDQUFDOztRQUM1QkYsUUFBUSxFQUFFRSxJQUFJLEdBQU1BLElBQUksR0FBRyxDQUFDOztRQUM1QkYsUUFBUSxFQUFFRSxJQUFJLEdBQU1BLElBQUksR0FBRyxDQUFDOztJQUVoQyxDQUFDO0lBR0QsTUFBTSw2RUFBQzs7d0ZBRUVDLENBQUc7O29CQUFDLENBQUs7b0JBQU9KLEtBQUs7Ozs7Ozs7d0ZBQ2ZLLENBQUE7Z0JBQUNDLE9BQU8sRUFBRUosTUFBTTswQkFBRSxDQUFHOzs7Ozs7OztBQUd4QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzLzA5LXF1aXovMDktMDQtU3RhdGUtcHJldi9pbmRleC50c3g/ZWE4NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByZXZzdGF0ZVBhZ2UoKXtcblxuICAgIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGUoMCk7XG5cbiAgICBmdW5jdGlvbiBzdW1BbGwoKXtcbiAgICAgICAgc2V0U3RhdGUoKHByZXYpID0+IChwcmV2ICsgMSkpO1xuICAgICAgICBzZXRTdGF0ZSgocHJldikgPT4gKHByZXYgKyAyKSk7XG4gICAgICAgIHNldFN0YXRlKChwcmV2KSA9PiAocHJldiArIDMpKTtcbiAgICAgICAgc2V0U3RhdGUoKHByZXYpID0+IChwcmV2ICsgNCkpO1xuXG4gICAgfVxuXG5cbiAgICByZXR1cm4oXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2PuqysOqzvOuKlDoge3N0YXRlfTwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtzdW1BbGx9PuyLpO2WiSE8L2J1dHRvbj5cbiAgICAgICAgPC8+XG4gICAgKVxufSJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByZXZzdGF0ZVBhZ2UiLCJzdGF0ZSIsInNldFN0YXRlIiwic3VtQWxsIiwicHJldiIsImRpdiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/09-quiz/09-04-State-prev/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/09-quiz/09-04-State-prev/index.tsx"));
module.exports = __webpack_exports__;

})();