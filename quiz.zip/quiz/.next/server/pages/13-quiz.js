"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/13-quiz";
exports.ids = ["pages/13-quiz"];
exports.modules = {

/***/ "./pages/13-quiz/index.tsx":
/*!*********************************!*\
  !*** ./pages/13-quiz/index.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ComponentLifecycle)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction ComponentLifecycle() {\n    const { 0: isChange , 1: setIsChange  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const inputRef = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createRef)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        console.log(\"update!!!!!!\");\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        var ref;\n        alert(\"Rendered!\");\n        (ref = inputRef.current) === null || ref === void 0 ? void 0 : ref.focus();\n        return ()=>{\n            alert(\"Bye!!\");\n        };\n    }, []);\n    const onClickChange = ()=>{\n        alert(\"Changed!!\");\n        setIsChange(true);\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickChange,\n                children: \"변경\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/index.tsx\",\n                lineNumber: 43,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/index.tsx\",\n                lineNumber: 44,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                ref: inputRef\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/index.tsx\",\n                lineNumber: 45,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/index.tsx\",\n        lineNumber: 42,\n        columnNumber: 13\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xMy1xdWl6L2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFnRTtBQUN6QjtBQUt4QixRQUFRLENBQUNJLGtCQUFrQixHQUFFLENBQUM7SUFDekMsS0FBSyxNQUFFQyxRQUFRLE1BQUVDLFdBQVcsTUFBSUosK0NBQVEsQ0FBQyxLQUFLO0lBQzlDLEtBQUssQ0FBQ0ssTUFBTSxHQUFHSixzREFBUztJQUN4QixLQUFLLENBQUNLLFFBQVEsaUJBQUdSLGdEQUFTLENBQW1CLElBQUk7SUFJakRDLGdEQUFTLEtBQU0sQ0FBQztRQUNaUSxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFjO0lBQzlCLENBQUMsRUFBQyxDQUFDLENBQUM7SUFJSlQsZ0RBQVMsS0FBTyxDQUFDO1lBRWJPLEdBQWdCO1FBRGhCRyxLQUFLLENBQUMsQ0FBVztTQUNqQkgsR0FBZ0IsR0FBaEJBLFFBQVEsQ0FBQ0ksT0FBTyxjQUFoQkosR0FBZ0IsS0FBaEJBLElBQUksQ0FBSkEsQ0FBdUIsR0FBdkJBLElBQUksQ0FBSkEsQ0FBdUIsR0FBdkJBLEdBQWdCLENBQUVLLEtBQUs7UUFDdkIsTUFBTSxLQUFPLENBQUM7WUFDVkYsS0FBSyxDQUFDLENBQU87UUFDYixDQUFDO0lBQ1QsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUlKLEtBQUssQ0FBQ0csYUFBYSxPQUFTLENBQUM7UUFDekJILEtBQUssQ0FBRSxDQUFXO1FBQ2xCTCxXQUFXLENBQUMsSUFBSTtJQUNwQixDQUFDO0lBR0QsS0FBSyxDQUFDUyxXQUFXLE9BQVMsQ0FBQztRQUN2QlIsTUFBTSxDQUFDUyxJQUFJLENBQUMsQ0FBRztJQUNuQixDQUFDO0lBR0csTUFBTSw2RUFDREMsQ0FBRzs7d0ZBQ0hDLENBQU07Z0JBQUNDLE9BQU8sRUFBRUwsYUFBYTswQkFBRSxDQUFFOzs7Ozs7d0ZBQzdCSSxDQUFFO2dCQUFDQyxPQUFPLEVBQUVKLFdBQVc7MEJBQUUsQ0FBRTs7Ozs7O3dGQUMvQkssQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQVU7Z0JBQUNDLEdBQUcsRUFBRWQsUUFBUTs7Ozs7Ozs7Ozs7O0FBT2hELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vcGFnZXMvMTMtcXVpei9pbmRleC50c3g/NDMxNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgY3JlYXRlUmVmLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuXG5cblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb21wb25lbnRMaWZlY3ljbGUoKXtcbiAgICBjb25zdCBbaXNDaGFuZ2UsIHNldElzQ2hhbmdlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICAgIGNvbnN0IGlucHV0UmVmID0gY3JlYXRlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXG5cblxuXG4gICAgdXNlRWZmZWN0KCgpPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZSEhISEhIVwiKVxuICAgIH0sW10pXG5cblxuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgYWxlcnQoXCJSZW5kZXJlZCFcIik7XG4gICAgICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKClcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGFsZXJ0KFwiQnllISFcIilcbiAgICAgICAgICAgIH1cbiAgICB9LFtdKVxuXG5cblxuICAgIGNvbnN0IG9uQ2xpY2tDaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgIGFsZXJ0KCBcIkNoYW5nZWQhIVwiKVxuICAgICAgICBzZXRJc0NoYW5nZSh0cnVlKVxuICAgIH1cblxuXG4gICAgY29uc3Qgb25DbGlja01vdmUgPSAoKSA9PiB7XG4gICAgICAgIHJvdXRlci5wdXNoKFwiL1wiKTtcbiAgICB9XG5cblxuICAgICAgICByZXR1cm4oXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQ2hhbmdlfT7rs4Dqsr08L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja01vdmV9PuydtOuPmTwvYnV0dG9uPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIHJlZj17aW5wdXRSZWZ9PjwvaW5wdXQ+XG4gICAgICAgICAgICA8L2Rpdj4gXG4gICAgICAgIClcbiAgICBcblxuICAgIFxuICAgIFxufVxuXG5cbiJdLCJuYW1lcyI6WyJjcmVhdGVSZWYiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsIkNvbXBvbmVudExpZmVjeWNsZSIsImlzQ2hhbmdlIiwic2V0SXNDaGFuZ2UiLCJyb3V0ZXIiLCJpbnB1dFJlZiIsImNvbnNvbGUiLCJsb2ciLCJhbGVydCIsImN1cnJlbnQiLCJmb2N1cyIsIm9uQ2xpY2tDaGFuZ2UiLCJvbkNsaWNrTW92ZSIsInB1c2giLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIiwiaW5wdXQiLCJ0eXBlIiwicmVmIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/13-quiz/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/13-quiz/index.tsx"));
module.exports = __webpack_exports__;

})();