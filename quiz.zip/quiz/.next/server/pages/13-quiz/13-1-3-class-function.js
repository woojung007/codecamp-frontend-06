"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/13-quiz/13-1-3-class-function";
exports.ids = ["pages/13-quiz/13-1-3-class-function"];
exports.modules = {

/***/ "./pages/13-quiz/13-1-3-class-function/index.tsx":
/*!*******************************************************!*\
  !*** ./pages/13-quiz/13-1-3-class-function/index.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyComponent)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction MyComponent() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    const inputRef = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createRef)();\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    }, [\n        count\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        var ref;\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n        (ref = inputRef.current) === null || ref === void 0 ? void 0 : ref.focus();\n        return ()=>{\n            alert(\"컴포넌트가 제거됩니다~\");\n        };\n    }, []);\n    const onClickCounter = ()=>{\n        setCount((prev)=>prev + 1\n        );\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    console.log(\"마운트 시작\");\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                ref: inputRef\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/13-1-3-class-function/index.tsx\",\n                lineNumber: 40,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"카운트: \",\n                    count\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/13-1-3-class-function/index.tsx\",\n                lineNumber: 41,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickCounter,\n                children: \"카운트(+1)\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/13-1-3-class-function/index.tsx\",\n                lineNumber: 42,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/13-quiz/13-1-3-class-function/index.tsx\",\n                lineNumber: 43,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xMy1xdWl6LzEzLTEtMy1jbGFzcy1mdW5jdGlvbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBZ0U7QUFDekI7QUFFeEIsUUFBUSxDQUFDSSxXQUFXLEdBQUUsQ0FBQztJQUNsQyxLQUFLLE1BQUVDLEtBQUssTUFBRUMsUUFBUSxNQUFJTCwrQ0FBUSxDQUFDLENBQUM7SUFDcEMsS0FBSyxDQUFDTSxRQUFRLGlCQUFHUCxnREFBUztJQUMxQixLQUFLLENBQUNRLE1BQU0sR0FBR0wsc0RBQVM7SUFLeEJELGdEQUFTLEtBQU0sQ0FBQztRQUNaTyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFlO0lBQ1QsQ0FBckIsRUFBQyxDQUFDTDtRQUFBQSxLQUFLO0lBQUEsQ0FBQztJQUlUSCxnREFBUyxLQUFLLENBQUM7WUFFWEssR0FBZ0I7UUFEaEJFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQXdDO1NBQ3BESCxHQUFnQixHQUFoQkEsUUFBUSxDQUFDSSxPQUFPLGNBQWhCSixHQUFnQixLQUFoQkEsSUFBSSxDQUFKQSxDQUF1QixHQUF2QkEsSUFBSSxDQUFKQSxDQUF1QixHQUF2QkEsR0FBZ0IsQ0FBRUssS0FBSztRQUN2QixNQUFNLEtBQU8sQ0FBQztZQUNWQyxLQUFLLENBQUMsQ0FBYztRQUNKLENBQW5CO0lBQ0wsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUdKLEtBQUssQ0FBQ0MsY0FBYyxPQUFTLENBQUM7UUFDMUJSLFFBQVEsRUFBQ1MsSUFBSSxHQUFJQSxJQUFJLEdBQUcsQ0FBQzs7SUFDN0IsQ0FBQztJQUdELEtBQUssQ0FBQ0MsV0FBVyxPQUFTLENBQUM7UUFDdkJSLE1BQU0sQ0FBQ1MsSUFBSSxDQUFDLENBQUc7SUFDbkIsQ0FBQztJQUVEUixPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFRO0lBRVYsTUFBSjs7d0ZBRURRLENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFVO2dCQUFDQyxHQUFHLEVBQUViLFFBQVE7Ozs7Ozt3RkFDbkNjLENBQUc7O29CQUFDLENBQUs7b0JBQU9oQixLQUFLOzs7Ozs7O3dGQUNmaUIsQ0FBQTtnQkFBQ0MsT0FBTyxFQUFFVCxjQUFjOzBCQUFFLENBQU87Ozs7Ozt3RkFDakNRLENBQUE7Z0JBQUNDLE9BQU8sRUFBRVAsV0FBVzswQkFBRSxDQUFJOzs7Ozs7OztBQUkxQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzLzEzLXF1aXovMTMtMS0zLWNsYXNzLWZ1bmN0aW9uL2luZGV4LnRzeD81ZjA4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgY3JlYXRlUmVmLCB1c2VTdGF0ZSx1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15Q29tcG9uZW50KCl7XG4gICAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZSgwKVxuICAgIGNvbnN0IGlucHV0UmVmID0gY3JlYXRlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KCk7XG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcblxuXG5cblxuICAgIHVzZUVmZmVjdCgoKT0+IHtcbiAgICAgICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg67OA6rK965CQ7Iq164uI64ukflwiKTtcbiAgICB9LFtjb3VudF0pXG5cblxuXG4gICAgdXNlRWZmZWN0KCgpPT57XG4gICAgICAgIGNvbnNvbGUubG9nKFwi7Lu07Y+s64SM7Yq46rCAIOuniOyatO2KuOuQkOyKteuLiOuLpH5cIik7XG4gICAgICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBhbGVydChcIuy7tO2PrOuEjO2KuOqwgCDsoJzqsbDrkKnri4jri6R+XCIpO1xuICAgICAgICB9XG4gICAgfSxbXSlcblxuXG4gICAgY29uc3Qgb25DbGlja0NvdW50ZXIgPSAoKSA9PiB7XG4gICAgICAgIHNldENvdW50KHByZXYgPT4gcHJldiArIDEpXG4gICAgfTtcblxuXG4gICAgY29uc3Qgb25DbGlja01vdmUgPSAoKSA9PiB7XG4gICAgICAgIHJvdXRlci5wdXNoKFwiL1wiKVxuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwi66eI7Jq07Yq4IOyLnOyekVwiKTtcblxuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgcmVmPXtpbnB1dFJlZn0gLz5cbiAgICAgICAgPGRpdj7subTsmrTtirg6IHtjb3VudH08L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQ291bnRlcn0+7Lm07Jq07Yq4KCsxKTwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tNb3ZlfT7snbTrj5ntlZjquLA8L2J1dHRvbj5cbiAgICAgIDwvPlxuICAgICk7XG5cbn0iXSwibmFtZXMiOlsiY3JlYXRlUmVmIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSb3V0ZXIiLCJNeUNvbXBvbmVudCIsImNvdW50Iiwic2V0Q291bnQiLCJpbnB1dFJlZiIsInJvdXRlciIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50IiwiZm9jdXMiLCJhbGVydCIsIm9uQ2xpY2tDb3VudGVyIiwicHJldiIsIm9uQ2xpY2tNb3ZlIiwicHVzaCIsImlucHV0IiwidHlwZSIsInJlZiIsImRpdiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/13-quiz/13-1-3-class-function/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/13-quiz/13-1-3-class-function/index.tsx"));
module.exports = __webpack_exports__;

})();