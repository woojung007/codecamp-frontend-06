"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/15-quiz";
exports.ids = ["pages/15-quiz"];
exports.modules = {

/***/ "./pages/15-quiz/index.tsx":
/*!*********************************!*\
  !*** ./pages/15-quiz/index.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ OpenAPIQuizPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction OpenAPIQuizPage() {\n    const { 0: dogUrl , 1: setDogUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const dog = async ()=>{\n            const result = await axios.get(\"https://dog.ceo/api/breeds/image/random\");\n            setDogUrl(result.data.message);\n        };\n        dog();\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n            src: dogUrl\n        }, void 0, false, {\n            fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/15-quiz/index.tsx\",\n            lineNumber: 22,\n            columnNumber: 13\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNS1xdWl6L2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBMkM7QUFPNUIsUUFBUSxDQUFDRSxlQUFlLEdBQUUsQ0FBQztJQUN0QyxLQUFLLE1BQUVDLE1BQU0sTUFBRUMsU0FBUyxNQUFHSiwrQ0FBUSxDQUFDLENBQUU7SUFHdENDLGdEQUFTLEtBQUssQ0FBQztRQUNYLEtBQUssQ0FBQ0ksR0FBRyxhQUFjLENBQUM7WUFDcEIsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDQyxLQUFLLENBQUNDLEdBQUcsQ0FBQyxDQUF5QztZQUN4RUosU0FBUyxDQUFDRSxNQUFNLENBQUNHLElBQUksQ0FBQ0MsT0FBTztRQUNqQyxDQUFDO1FBQ0RMLEdBQUc7SUFDUCxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBRUosTUFBTSw2RUFBQzs4RkFFRU0sQ0FBRztZQUFDQyxHQUFHLEVBQUVULE1BQU07Ozs7Ozs7QUFHNUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9wYWdlcy8xNS1xdWl6L2luZGV4LnRzeD9hN2NhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cblxuXG5cblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPcGVuQVBJUXVpelBhZ2UoKXtcbiAgICBjb25zdCBbZG9nVXJsLCBzZXREb2dVcmxdID11c2VTdGF0ZShcIlwiKVxuXG5cbiAgICB1c2VFZmZlY3QoKCk9PntcbiAgICAgICAgY29uc3QgZG9nID0gYXN5bmMoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBheGlvcy5nZXQoXCJodHRwczovL2RvZy5jZW8vYXBpL2JyZWVkcy9pbWFnZS9yYW5kb21cIilcbiAgICAgICAgICAgIHNldERvZ1VybChyZXN1bHQuZGF0YS5tZXNzYWdlKVxuICAgICAgICB9O1xuICAgICAgICBkb2coKVxuICAgIH0sW10pXG5cbiAgICByZXR1cm4oXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8aW1nIHNyYz17ZG9nVXJsfS8+XG4gICAgICAgIDwvPlxuICAgIClcbn0iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJPcGVuQVBJUXVpelBhZ2UiLCJkb2dVcmwiLCJzZXREb2dVcmwiLCJkb2ciLCJyZXN1bHQiLCJheGlvcyIsImdldCIsImRhdGEiLCJtZXNzYWdlIiwiaW1nIiwic3JjIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/15-quiz/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/15-quiz/index.tsx"));
module.exports = __webpack_exports__;

})();