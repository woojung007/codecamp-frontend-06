/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/dist/antd.css */ \"./node_modules/antd/dist/antd.css\");\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/commons/styles/globalStyles */ \"./src/commons/styles/globalStyles.ts\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_components_commons_layout_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/commons/layout/index */ \"./src/components/commons/layout/index.tsx\");\n\n\n// import '../styles/globals.css'\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloClient({\n        uri: \"http://backend06.codebootcamp.co.kr/graphql\",\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloProvider, {\n        client: client,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_4__.Global, {\n                styles: _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_3__.globalStyles\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/_app.tsx\",\n                lineNumber: 21,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_commons_layout_index__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/_app.tsx\",\n                    lineNumber: 23,\n                    columnNumber: 11\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/_app.tsx\",\n                lineNumber: 22,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/pages/_app.tsx\",\n        lineNumber: 20,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBMkI7QUFDM0IsRUFBaUM7QUFDeUM7QUFDVDtBQUMxQjtBQUNvQjtTQUlsRE0sS0FBSyxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxHQUFFQyxTQUFTLEVBQVcsQ0FBQyxFQUFFLENBQUM7SUFFbEQsS0FBSyxDQUFDQyxNQUFNLEdBQUcsR0FBRyxDQUFDVCx3REFBWSxDQUFDLENBQUM7UUFDL0JVLEdBQUcsRUFBRyxDQUE2QztRQUNuREMsS0FBSyxFQUFHLEdBQUcsQ0FBQ1QseURBQWE7SUFDM0IsQ0FBQztJQUlELE1BQU0sNkVBQ0hELDBEQUFjO1FBQUNRLE1BQU0sRUFBRUEsTUFBTTs7d0ZBQzNCTCxrREFBTTtnQkFBQ1EsTUFBTSxFQUFFVCwwRUFBWTs7Ozs7O3dGQUN6QkUsNEVBQU07c0dBQ0pFLFNBQVM7dUJBQUtDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS2xDLENBQUM7QUFFRCxpRUFBZUYsS0FBSyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICdhbnRkL2Rpc3QvYW50ZC5jc3MnO1xuLy8gaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXG5pbXBvcnQge0Fwb2xsb0NsaWVudCwgQXBvbGxvUHJvdmlkZXIsIEluTWVtb3J5Q2FjaGV9IGZyb20gJ0BhcG9sbG8vY2xpZW50J1xuaW1wb3J0IHsgZ2xvYmFsU3R5bGVzIH0gZnJvbSAnLi4vc3JjL2NvbW1vbnMvc3R5bGVzL2dsb2JhbFN0eWxlcyc7XG5pbXBvcnQgeyBHbG9iYWwgfSBmcm9tICdAZW1vdGlvbi9yZWFjdCc7XG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L2luZGV4JztcbmltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xuXG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfTogQXBwUHJvcHMpIHtcblxuICBjb25zdCBjbGllbnQgPSBuZXcgQXBvbGxvQ2xpZW50KHtcbiAgICB1cmkgOiBcImh0dHA6Ly9iYWNrZW5kMDYuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcbiAgICBjYWNoZSA6IG5ldyBJbk1lbW9yeUNhY2hlKClcbiAgfSlcblxuXG5cbiAgcmV0dXJuKCBcbiAgICA8QXBvbGxvUHJvdmlkZXIgY2xpZW50PXtjbGllbnR9PlxuICAgICAgPEdsb2JhbCBzdHlsZXM9e2dsb2JhbFN0eWxlc30gLz5cbiAgICAgICAgPExheW91dD5cbiAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICAgIDwvTGF5b3V0PlxuICAgIDwvQXBvbGxvUHJvdmlkZXI+XG5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcbiJdLCJuYW1lcyI6WyJBcG9sbG9DbGllbnQiLCJBcG9sbG9Qcm92aWRlciIsIkluTWVtb3J5Q2FjaGUiLCJnbG9iYWxTdHlsZXMiLCJHbG9iYWwiLCJMYXlvdXQiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImNsaWVudCIsInVyaSIsImNhY2hlIiwic3R5bGVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/commons/styles/globalStyles.ts":
/*!********************************************!*\
  !*** ./src/commons/styles/globalStyles.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n*{\n    margin: 0;\n    box-sizing: border-box;\n    font-size: 30px;\n    /* font-family:  \"myFont\"; */\n}\n\n\n    @font-face {\n        font-family: \"myFont\";\n        src: url(/fonts/scifibit.ttf);\n    }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFrQztBQUszQixLQUFLLENBQUNDLFlBQVksR0FBR0QsK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7OztBQWFoQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLnRzP2M3NzUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtjc3N9IGZyb20gJ0BlbW90aW9uL3JlYWN0J1xuXG5cblxuXG5leHBvcnQgY29uc3QgZ2xvYmFsU3R5bGVzID0gY3NzYFxuKntcbiAgICBtYXJnaW46IDA7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgLyogZm9udC1mYW1pbHk6ICBcIm15Rm9udFwiOyAqL1xufVxuXG5cbiAgICBAZm9udC1mYWNlIHtcbiAgICAgICAgZm9udC1mYW1pbHk6IFwibXlGb250XCI7XG4gICAgICAgIHNyYzogdXJsKC9mb250cy9zY2lmaWJpdC50dGYpO1xuICAgIH1cbmAgXG5cblxuXG5cbiJdLCJuYW1lcyI6WyJjc3MiLCJnbG9iYWxTdHlsZXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/styles/globalStyles.ts\n");

/***/ }),

/***/ "./src/components/commons/layout/banner/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/banner/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Sliders)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-slick */ \"react-slick\");\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ \"./node_modules/slick-carousel/slick/slick.css\");\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ \"./node_modules/slick-carousel/slick/slick-theme.css\");\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);\n\n\n// import { Component } from \"react\";\n\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 500px;\n    background-color: pink;\n`;\nconst SimpleSlider = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default()((react_slick__WEBPACK_IMPORTED_MODULE_2___default()))`\n    .slick-slide div{\n        outline: none;\n        cursor: pointer;\n    }\n\n`;\nconst Img = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`\n    width: 800px;\n    height: 500px;\n    margin-left: 1500px;\n    margin: auto;\n`;\nfunction Sliders() {\n    const settings = {\n        dots: true,\n        infinite: true,\n        speed: 500,\n        slidesToShow: 1,\n        slidesToScroll: 1,\n        centerMode: true\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {\n            ...settings\n        }, void 0, false, {\n            fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/banner/index.tsx\",\n            lineNumber: 47,\n            columnNumber: 17\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/banner/index.tsx\",\n        lineNumber: 46,\n        columnNumber: 11\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9iYW5uZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFvQztBQUNwQyxFQUFxQztBQUNMO0FBQ087QUFDTTtBQUc3QyxLQUFLLENBQUNFLE9BQU8sR0FBR0YsNERBQVUsQ0FBQzs7O0FBRzNCO0FBR0EsS0FBSyxDQUFDSSxZQUFZLEdBQUdKLHNEQUFNLENBQUNDLG9EQUFNLEVBQUU7Ozs7OztBQU1wQztBQUlBLEtBQUssQ0FBQ0ksR0FBRyxHQUFHTCw0REFBVSxDQUFDOzs7OztBQUt2QjtBQUllLFFBQVEsQ0FBQ08sT0FBTyxHQUFFLENBQUM7SUFFOUIsS0FBSyxDQUFDQyxRQUFRLEdBQUcsQ0FBQztRQUNkQyxJQUFJLEVBQUUsSUFBSTtRQUNWQyxRQUFRLEVBQUUsSUFBSTtRQUNkQyxLQUFLLEVBQUUsR0FBRztRQUNWQyxZQUFZLEVBQUUsQ0FBQztRQUNmQyxjQUFjLEVBQUUsQ0FBQztRQUNqQkMsVUFBVSxFQUFFLElBQUk7SUFDbEIsQ0FBQztJQUdDLE1BQU0sNkVBQ0haLE9BQU87OEZBQ0RELG9EQUFNO2VBQUtPLFFBQVE7Ozs7Ozs7Ozs7O0FBS2hDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9sYXlvdXQvYmFubmVyL2luZGV4LnRzeD9jODc0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuLy8gaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2suY3NzXCI7IFxuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XG5cblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICAgaGVpZ2h0OiA1MDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBwaW5rO1xuYFxuXG5cbmNvbnN0IFNpbXBsZVNsaWRlciA9IHN0eWxlZChTbGlkZXIpYFxuICAgIC5zbGljay1zbGlkZSBkaXZ7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG5cbmBcblxuXG5cbmNvbnN0IEltZyA9IHN0eWxlZC5pbWdgXG4gICAgd2lkdGg6IDgwMHB4O1xuICAgIGhlaWdodDogNTAwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDE1MDBweDtcbiAgICBtYXJnaW46IGF1dG87XG5gXG5cblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTbGlkZXJzKCl7XG5cbiAgICBjb25zdCBzZXR0aW5ncyA9IHtcbiAgICAgICAgZG90czogdHJ1ZSxcbiAgICAgICAgaW5maW5pdGU6IHRydWUsXG4gICAgICAgIHNwZWVkOiA1MDAsXG4gICAgICAgIHNsaWRlc1RvU2hvdzogMSxcbiAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgICAgIGNlbnRlck1vZGU6IHRydWUsXG4gICAgICB9O1xuICAgICAgXG5cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8V3JhcHBlcj5cbiAgICAgICAgICAgICAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XG4gICAgICAgICAgICAgICAgPC9TbGlkZXI+XG4gICAgICAgICAgICA8L1dyYXBwZXI+XG4gICAgICAgICk7XG4gICAgXG4gICAgfVxuXG4gXG4gXG5cblxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIlNsaWRlciIsIldyYXBwZXIiLCJkaXYiLCJTaW1wbGVTbGlkZXIiLCJJbWciLCJpbWciLCJTbGlkZXJzIiwic2V0dGluZ3MiLCJkb3RzIiwiaW5maW5pdGUiLCJzcGVlZCIsInNsaWRlc1RvU2hvdyIsInNsaWRlc1RvU2Nyb2xsIiwiY2VudGVyTW9kZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/commons/layout/banner/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/footer/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/footer/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutFooter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 100px;\n    background-color: green;\n`;\nfunction LayoutFooter() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"푸터영역\"\n    }, void 0, false, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/footer/index.tsx\",\n        lineNumber: 14,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9mb290ZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUlwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQUUsQ0FBQztJQUluQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQUk7Ozs7OztBQUN4QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L2Zvb3Rlci9pbmRleC50c3g/YzJhOCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuXG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICAgIGhlaWdodDogMTAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XG5gXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dEZvb3Rlcigpe1xuXG5cblxuICAgIHJldHVybiA8V3JhcHBlcj7tkbjthLDsmIHsl608L1dyYXBwZXI+XG59Il0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRGb290ZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/commons/layout/footer/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/header/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/header/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutHeader)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 100px;\n    background-color: crimson;\n`;\nfunction LayoutHeader() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"헤더영역\"\n    }, void 0, false, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/header/index.tsx\",\n        lineNumber: 14,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9oZWFkZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUlwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQUUsQ0FBQztJQUluQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQUk7Ozs7OztBQUN4QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L2hlYWRlci9pbmRleC50c3g/NjdiNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuXG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICAgIGhlaWdodDogMTAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogY3JpbXNvbjtcbmBcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0SGVhZGVyKCl7XG5cblxuXG4gICAgcmV0dXJuIDxXcmFwcGVyPu2XpOuNlOyYgeyXrTwvV3JhcHBlcj5cbn0iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dEhlYWRlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/commons/layout/header/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/commons/layout/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./banner */ \"./src/components/commons/layout/banner/index.tsx\");\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./header */ \"./src/components/commons/layout/header/index.tsx\");\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./navigation */ \"./src/components/commons/layout/navigation/index.tsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./footer */ \"./src/components/commons/layout/footer/index.tsx\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _sidebar_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sidebar/index */ \"./src/components/commons/layout/sidebar/index.tsx\");\n\n\n\n\n\n\n\n\nconst BodyWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    display: flex;\n`;\nconst Body = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    width: 100%;\n    background-color: white;\n`;\nconst HIDDEN_HEADERS = [\n    \"/11-quiz\"\n];\nfunction Layout(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();\n    console.log(router);\n    const isHidden = HIDDEN_HEADERS.includes(router.asPath);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                lineNumber: 39,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_banner__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                lineNumber: 40,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                lineNumber: 41,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(BodyWrapper, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: !isHidden && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_sidebar_index__WEBPACK_IMPORTED_MODULE_7__[\"default\"], {}, void 0, false, {\n                            fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                            lineNumber: 44,\n                            columnNumber: 27\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                        lineNumber: 43,\n                        columnNumber: 13\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Body, {\n                        children: props.children\n                    }, void 0, false, {\n                        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                        lineNumber: 46,\n                        columnNumber: 13\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                lineNumber: 42,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/index.tsx\",\n                lineNumber: 48,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFtQztBQUNBO0FBQ1E7QUFDUjtBQUNDO0FBRUc7QUFDSTtBQUczQyxLQUFLLENBQUNPLFdBQVcsR0FBR0gsNERBQVUsQ0FBQzs7QUFFL0I7QUFFQSxLQUFLLENBQUNLLElBQUksR0FBR0wsNERBQVUsQ0FBQzs7O0FBR3hCO0FBT0EsS0FBSyxDQUFDTSxjQUFjLEdBQUcsQ0FBQztJQUNwQixDQUFVO0FBQ2QsQ0FBQztBQUdjLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxLQUFtQixFQUFDLENBQUM7SUFDaEQsS0FBSyxDQUFDQyxNQUFNLEdBQUdSLHNEQUFTO0lBQ3hCUyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0YsTUFBTTtJQUVsQixLQUFLLENBQUNHLFFBQVEsR0FBR04sY0FBYyxDQUFDTyxRQUFRLENBQUNKLE1BQU0sQ0FBQ0ssTUFBTTtJQUV0RCxNQUFNOzt3RkFHR2pCLCtDQUFZOzs7Ozt3RkFDWkQsK0NBQVk7Ozs7O3dGQUNaRSxtREFBZ0I7Ozs7O3dGQUNoQkssV0FBVzs7Z0dBQ1hDLENBQUc7bUNBQ0ZRLFFBQVEsZ0ZBQUtWLHNEQUFhOzs7Ozs7Ozs7O2dHQUUzQkcsSUFBSTtrQ0FBRUcsS0FBSyxDQUFDTyxRQUFROzs7Ozs7Ozs7Ozs7d0ZBRXBCaEIsK0NBQVk7Ozs7Ozs7QUFHekIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9pbmRleC50c3g/ZDhlYyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGF5b3V0QmFubmVyIGZyb20gXCIuL2Jhbm5lclwiXG5pbXBvcnQgTGF5b3V0SGVhZGVyIGZyb20gXCIuL2hlYWRlclwiXG5pbXBvcnQgTGF5b3V0TmF2aWdhdGlvbiBmcm9tIFwiLi9uYXZpZ2F0aW9uXCJcbmltcG9ydCBMYXlvdXRGb290ZXIgZnJvbSBcIi4vZm9vdGVyXCJcbmltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiXG5pbXBvcnQge1JlYWN0Tm9kZX0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIlxuaW1wb3J0IExheW91dFNpZGViYXIgZnJvbSAnLi9zaWRlYmFyL2luZGV4JztcblxuXG5jb25zdCBCb2R5V3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICAgZGlzcGxheTogZmxleDtcbmBcblxuY29uc3QgQm9keSA9IHN0eWxlZC5kaXZgXG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG5gXG5cbmludGVyZmFjZSBJTGF5b3V0UHJvcHN7XG4gICAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbn1cblxuXG5jb25zdCBISURERU5fSEVBREVSUyA9IFtcbiAgICBcIi8xMS1xdWl6XCJcbl1cblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQocHJvcHM6IElMYXlvdXRQcm9wcyl7XG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgICBjb25zb2xlLmxvZyhyb3V0ZXIpXG5cbiAgICBjb25zdCBpc0hpZGRlbiA9IEhJRERFTl9IRUFERVJTLmluY2x1ZGVzKHJvdXRlci5hc1BhdGgpXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8TGF5b3V0SGVhZGVyIC8+XG4gICAgICAgICAgICA8TGF5b3V0QmFubmVyIC8+XG4gICAgICAgICAgICA8TGF5b3V0TmF2aWdhdGlvbiAvPlxuICAgICAgICAgICAgPEJvZHlXcmFwcGVyPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHshaXNIaWRkZW4gJiYgPExheW91dFNpZGViYXIgLz4gfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Qm9keT57cHJvcHMuY2hpbGRyZW59PC9Cb2R5PlxuICAgICAgICAgICAgPC9Cb2R5V3JhcHBlcj5cbiAgICAgICAgICAgIDxMYXlvdXRGb290ZXIgLz5cbiAgICAgICAgPC8+XG4gICAgKVxufSJdLCJuYW1lcyI6WyJMYXlvdXRCYW5uZXIiLCJMYXlvdXRIZWFkZXIiLCJMYXlvdXROYXZpZ2F0aW9uIiwiTGF5b3V0Rm9vdGVyIiwic3R5bGVkIiwidXNlUm91dGVyIiwiTGF5b3V0U2lkZWJhciIsIkJvZHlXcmFwcGVyIiwiZGl2IiwiQm9keSIsIkhJRERFTl9IRUFERVJTIiwiTGF5b3V0IiwicHJvcHMiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwiaXNIaWRkZW4iLCJpbmNsdWRlcyIsImFzUGF0aCIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/commons/layout/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/navigation/index.tsx":
/*!************************************************************!*\
  !*** ./src/components/commons/layout/navigation/index.tsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 100px;\n    background-color: orange;\n`;\nfunction LayoutNavigation() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"네비게이션 영역\"\n    }, void 0, false, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/navigation/index.tsx\",\n        lineNumber: 14,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFJcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7OztBQUczQjtBQUVlLFFBQVEsQ0FBQ0csZ0JBQWdCLEdBQUUsQ0FBQztJQUl2QyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQVE7Ozs7OztBQUM1QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L25hdmlnYXRpb24vaW5kZXgudHN4P2FjZmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5cblxuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcbmBcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0TmF2aWdhdGlvbigpe1xuXG5cblxuICAgIHJldHVybiA8V3JhcHBlcj7rhKTruYTqsozsnbTshZgg7JiB7JetPC9XcmFwcGVyPlxufSJdLCJuYW1lcyI6WyJzdHlsZWQiLCJXcmFwcGVyIiwiZGl2IiwiTGF5b3V0TmF2aWdhdGlvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/commons/layout/navigation/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/sidebar/index.tsx":
/*!*********************************************************!*\
  !*** ./src/components/commons/layout/sidebar/index.tsx ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutSidebar)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    width: 500px;\n    height: auto;\n    background-color: lightskyblue;\n`;\nfunction LayoutSidebar() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"사이드바 영역\"\n    }, void 0, false, {\n        fileName: \"/Users/Woojung/Desktop/codecamp-frontend-06/quiz/src/components/commons/layout/sidebar/index.tsx\",\n        lineNumber: 15,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9zaWRlYmFyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFHcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7Ozs7QUFJM0I7QUFHZSxRQUFRLENBQUNHLGFBQWEsR0FBRSxDQUFDO0lBSXBDLE1BQU0sNkVBQUVGLE9BQU87a0JBQUMsQ0FBTzs7Ozs7O0FBQzNCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9sYXlvdXQvc2lkZWJhci9pbmRleC50c3g/ODYzNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgICB3aWR0aDogNTAwcHg7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0c2t5Ymx1ZTtcbmBcblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRTaWRlYmFyKCl7XG5cblxuXG4gICAgcmV0dXJuIDxXcmFwcGVyPuyCrOydtOuTnOuwlCDsmIHsl608L1dyYXBwZXI+XG59Il0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRTaWRlYmFyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/commons/layout/sidebar/index.tsx\n");

/***/ }),

/***/ "./node_modules/antd/dist/antd.css":
/*!*****************************************!*\
  !*** ./node_modules/antd/dist/antd.css ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();