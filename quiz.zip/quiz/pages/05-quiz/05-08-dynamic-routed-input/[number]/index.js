import BoardRead from "../../../src/components/units/board/read/BoardRead.container";



export default function StaticRoutedPage(){

return <BoardRead />
}