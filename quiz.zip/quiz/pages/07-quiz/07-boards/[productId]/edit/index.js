//  수정하기 페이지
import CreatProduct from "../../../../src/components/units/product/create/CreateProduct.container";


export default function ProductEditPage(){

    return <CreatProduct  isEdit={true}/>

}