//상품등록 페이지
import CreatProduct from "../../../src/components/units/product/create/CreateProduct.container";



export default function CreatProductPage(){

    return <CreatProduct isEdit={false}/>


}