export default function page(){

    return (
        <div>
            one 영역입니다
        </div>

    )
    

}