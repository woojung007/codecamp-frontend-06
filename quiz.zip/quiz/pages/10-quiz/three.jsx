export default function page(){

    return (
        <div>
            three 영역입니다
        </div>

    )
    

}