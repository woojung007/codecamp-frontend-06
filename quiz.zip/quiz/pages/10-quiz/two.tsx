export default function page(){

    return (
        <div>
            two 영역입니다
        </div>

    )
    

}