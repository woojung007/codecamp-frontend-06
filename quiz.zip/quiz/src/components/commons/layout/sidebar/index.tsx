import styled from '@emotion/styled'


const Wrapper = styled.div`
    width: 500px;
    height: 500px;
    background-color: lightskyblue;
`


export default function LayoutSidebar(){



    return <Wrapper>사이드바 영역</Wrapper>
}